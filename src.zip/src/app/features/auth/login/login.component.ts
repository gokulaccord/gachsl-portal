import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {

  username: string = '';
  password: string = '';

  constructor(
    private auth: AuthService,
    private router: Router
  ) {}

  login(): void {

    if (!this.username || !this.password) {
      alert('Please enter email and password');
      return;
    }

    this.auth.login(this.username, this.password).subscribe({
      next: (res: any) => {

        console.log('Login Response:', res);

        localStorage.setItem('token', res.token);

        if (res.refreshToken) {
          localStorage.setItem('refreshToken', res.refreshToken);
        }

        this.router.navigate(['/dashboard']);
      },
      error: (err) => {
        console.error(err);

        if (err.status === 401) {
          alert('Invalid email or password');
        } else {
          alert('Login failed. Please try again.');
        }
      }
    });
  }
}